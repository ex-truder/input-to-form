import { Link } from "react-router-dom";
import ProjectMedia from "../media/ProjectMedia";
import { getText } from "../../i18n/config";
import { useLocale } from "../../i18n/useLocale";

export default function ProjectCard({ project, index }) {
  const locale = useLocale();

  const ratio =
    project.ratio === "portrait"
      ? "md:row-span-3 min-h-[520px]"
      : project.ratio === "wide"
        ? "md:col-span-2 md:row-span-2 min-h-[360px]"
        : "md:row-span-2 min-h-[360px]";

  return (
    <Link
      to={`/${locale}/work/${project.slug}`}
      className={`group relative block overflow-hidden rounded-[1rem] bg-zinc-200 ${ratio}`}
      style={{ animationDelay: `${index * 50}ms` }}
    >
      <div className="absolute inset-0">
        <ProjectMedia
          media={project.cover}
          project={project}
          className="h-full min-h-0 rounded-none"
        />
      </div>

      <div className="absolute inset-0 z-10 bg-black/0 transition duration-300 group-hover:bg-black/5" />

      <div className="absolute inset-x-0 bottom-0 z-20 flex items-end justify-between gap-6 p-5 opacity-0 transition duration-600 group-hover:opacity-100">
        <div className="rounded-2xl bg-white/70 px-4 py-3 text-sm backdrop-blur-md">
          <h3 className="font-semibold tracking-tight text-zinc-950">
            {getText(project.title, locale)}
          </h3>
          <p className="mt-1 text-zinc-600">
            {getText(project.type, locale)}
          </p>
        </div>
      </div>
    </Link>
  );
}